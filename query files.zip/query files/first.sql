SELECT *,round(60*60/time_spent,0) as no_of_jobs_reviewed_per_hour_per_day
 FROM jobs;